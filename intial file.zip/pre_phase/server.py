from socketio import *

server = Server(async_mode='gevent')


@server.event
def connect(sid, environ, auth):
    print(sid, "connected!")


app = WSGIApp(server)
from gevent import pywsgi

pywsgi.WSGIServer(("127.0.0.1", 5000), app).serve_forever()
