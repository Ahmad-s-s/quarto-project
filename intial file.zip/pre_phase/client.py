from socketio import *

client = Client()
client.connect("http://127.0.0.1:5000")
